"use client";

import React, { useMemo, useState } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import ExcelReader from "@/app/dataexcel/ExcelReader";

/* ---------------------------- CONFIG ---------------------------- */
const COLORS = [
  "#3b82f6", // biru
  "#22c55e", // hijau
  "#f97316", // oranye
  "#8b5cf6", // ungu
  "#06b6d4", // cyan
  "#eab308", // kuning
  "#ef4444", // merah
];

type Jenis = "Pusat" | "Daerah";
type Gender = "Pria" | "Wanita";
type Jabatan = "Analis SDMA" | "Pranata SDMA" | "Asesor SDMA" | "Auditor ASN";
type Jenjang =
  | "Pemula"
  | "Terampil"
  | "Mahir"
  | "Penyelia"
  | "Pertama"
  | "Muda"
  | "Madya"
  | "Utama";

interface RecordRow {
  jenisInstansi: Jenis;
  namaInstansi: string;
  gender: Gender;
  usia: number;
  jabatan: Jabatan;
  jenjang: Jenjang;
}

/* ---------------------------- UTIL ---------------------------- */
const usiaBucket = (u: number): "<30" | "31-40" | "41-50" | ">50" => {
  if (u < 30) return "<30";
  if (u <= 40) return "31-40";
  if (u <= 50) return "41-50";
  return ">50";
};

const extractJenjang = (s: string): Jenjang => {
  const last = s.trim().split(/\s+/).pop() || "Pemula";
  return last as Jenjang;
};

const extractJabatan = (s: string): Jabatan => {
  if (s.includes("Analis")) return "Analis SDMA";
  if (s.includes("Pranata")) return "Pranata SDMA";
  if (s.includes("Asesor")) return "Asesor SDMA";
  if (s.includes("Auditor")) return "Auditor ASN";
  return "Pranata SDMA";
};

/* ---------------------------- CARD ---------------------------- */
const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div className="bg-white border border-gray-200 rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 p-4 flex flex-col">
    <h2 className="text-sm font-semibold mb-3 text-gray-700 border-b pb-2">{title}</h2>
    <div className="flex-1">{children}</div>
  </div>
);

/* ---------------------------- MAIN ---------------------------- */
export default function DashboardExcel() {
  const [excelData, setExcelData] = useState<Record<string, any[]>>({});

  // Ambil data utama dari sheet “Worksheet”
  const records = useMemo((): RecordRow[] => {
    const sheet = excelData["worksheet"] || excelData["Worksheet"] || [];
    if (!Array.isArray(sheet) || sheet.length === 0) return [];

    const unique = Array.from(new Map(sheet.map((r) => [r.NIP, r])).values());

    return unique.map((r: any) => {
      const instansi = String(r.Instansi || "").trim();
      const isPusat = instansi === "Badan Kepegawaian Negara";
      const jenjangRaw = String(r["Jenjang Jabatan"] || "");

      return {
        jenisInstansi: isPusat ? "Pusat" : "Daerah",
        namaInstansi: instansi || "-",
        gender:
          String(r.GENDER || "").toLowerCase() === "wanita"
            ? "Wanita"
            : "Pria",
        usia: parseInt(String(r.USIA || 0)) || 0,
        jabatan: extractJabatan(jenjangRaw),
        jenjang: extractJenjang(jenjangRaw),
      };
    });
  }, [excelData]);

  /* ---------------------------- AGGREGATE ---------------------------- */
  const byGender = useMemo(
    () => [
      { name: "Pria", value: records.filter((r) => r.gender === "Pria").length },
      { name: "Wanita", value: records.filter((r) => r.gender === "Wanita").length },
    ],
    [records]
  );

  const byInstansi = useMemo(
    () => [
      { name: "Pusat", value: records.filter((r) => r.jenisInstansi === "Pusat").length },
      { name: "Daerah", value: records.filter((r) => r.jenisInstansi === "Daerah").length },
    ],
    [records]
  );

  const byUsia = useMemo(() => {
    const buckets = ["<30", "31-40", "41-50", ">50"] as const;
    return buckets.map((b, i) => ({
      range: b,
      total: records.filter((r) => usiaBucket(r.usia) === b).length,
      color: COLORS[i % COLORS.length],
    }));
  }, [records]);

  const jabatanLabels: Jabatan[] = [
    "Analis SDMA",
    "Pranata SDMA",
    "Asesor SDMA",
    "Auditor ASN",
  ];
  const jenjangKeys: string[] = [
    "pratama",
    "muda",
    "madya",
    "utama",
    "terampil",
    "mahir",
    "penyelia",
  ];

  // Sesuaikan agar sesuai dummy chart
  const byJabatan = useMemo(() => {
    return jabatanLabels.map((j) => {
      const slice = records.filter((r) => r.jabatan === j);
      const row: any = { jabatan: j };

      row.pratama = slice.filter((r) =>
        ["Pertama"].includes(r.jenjang)
      ).length;
      row.muda = slice.filter((r) => ["Muda"].includes(r.jenjang)).length;
      row.madya = slice.filter((r) => ["Madya"].includes(r.jenjang)).length;
      row.utama = slice.filter((r) => ["Utama"].includes(r.jenjang)).length;
      row.terampil = slice.filter((r) => ["Terampil"].includes(r.jenjang)).length;
      row.mahir = slice.filter((r) => ["Mahir"].includes(r.jenjang)).length;
      row.penyelia = slice.filter((r) => ["Penyelia"].includes(r.jenjang)).length;

      return row;
    });
  }, [records]);

  /* ---------------------------- UI ---------------------------- */
  return (
    <div className="bg-[#f8f5f2] flex justify-start items-start p-10 min-h-screen">
      <div className="w-full max-w-7xl">
        {/* Header */}
        <h1 className="text-3xl font-bold text-gray-800 mb-6 text-center">
          Dashboard Demografi Peserta
        </h1>

        {/* Upload */}
        <div className="flex justify-center mb-6">
          <ExcelReader onDataLoaded={setExcelData} />
        </div>

        {records.length > 0 ? (
          <>
            {/* Grid atas (3 kolom) */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <Card title="Gender">
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={byGender} dataKey="value" nameKey="name" outerRadius={80} label>
                      {byGender.map((_, i) => (
                        <Cell key={i} fill={COLORS[i]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Card>

              <Card title="Jenis Instansi">
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie data={byInstansi} dataKey="value" nameKey="name" innerRadius={50} outerRadius={80} label>
                      {byInstansi.map((_, i) => (
                        <Cell key={i} fill={COLORS[i + 2]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </PieChart>
                </ResponsiveContainer>
              </Card>

              {/* 🔹 Distribusi Usia (IDENTIK dengan dummy) */}
              <Card title="Distribusi Usia">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={byUsia}
                    margin={{ top: 20, right: 30, left: 20, bottom: 40 }}
                  >
                    <XAxis dataKey="range" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="total" name="Jumlah">
                      {byUsia.map((entry, index) => (
                        <Cell
                          key={`cell-${index}`}
                          fill={entry.color}
                          className="cursor-pointer hover:opacity-80"
                        />
                      ))}
                      <LabelList dataKey="total" position="top" fontSize={12} />
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </div>

            {/* 🔹 Jumlah Pegawai per Jenjang Jabatan (IDENTIK dengan dummy) */}
            <div className="grid grid-cols-1 md:grid-cols-1 gap-6">
              <Card title="Jumlah Pegawai per Jenjang Jabatan">
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={byJabatan}
                    margin={{ top: 20, right: 30, left: 20, bottom: 40 }}
                  >
                    <XAxis dataKey="jabatan" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="pratama" fill="#22c55e" name="Ahli Pratama" />
                    <Bar dataKey="muda" fill="#3b82f6" name="Ahli Muda" />
                    <Bar dataKey="madya" fill="#8b5cf6" name="Ahli Madya" />
                    <Bar dataKey="utama" fill="#f97316" name="Ahli Utama" />
                    <Bar dataKey="terampil" fill="#06b6d4" name="Terampil" />
                    <Bar dataKey="mahir" fill="#eab308" name="Mahir" />
                    <Bar dataKey="penyelia" fill="#ef4444" name="Penyelia" />
                  </BarChart>
                </ResponsiveContainer>
              </Card>
            </div>
          </>
        ) : (
          <p className="text-gray-500 text-center mt-8">
            📄 Silakan unggah file Excel terlebih dahulu untuk menampilkan grafik.
          </p>
        )}
      </div>
    </div>
  );
}
