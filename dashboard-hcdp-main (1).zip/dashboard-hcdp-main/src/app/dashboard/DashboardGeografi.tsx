"use client";
import React from "react";
import {
  PieChart, Pie, BarChart, Bar,
  XAxis, YAxis, Tooltip, Legend,
  ResponsiveContainer, Cell, LabelList
} from "recharts";

const COLORS = ["#600DB5", "#E879F9", "#8B5CF6", "#C084FC", "#DDD6FE"];

// fungsi bantu buat ngelompokkan data
const groupByCount = (data: any[], key: string) => {
  const counts: Record<string, number> = {};
  data.forEach((item) => {
    const value = item[key] || "Tidak diketahui";
    counts[value] = (counts[value] || 0) + 1;
  });
  return Object.entries(counts).map(([name, value]) => ({ name, value }));
};

export default function DashboardGeografi({ data }: { data: any[] }) {
  if (!data || data.length === 0) return <p>Belum ada data.</p>;

  const genderData = groupByCount(data, "GENDER");
  const instansiData = groupByCount(data, "Instansi");
  const usiaData = groupByCount(data, "Rentang Usia");
  const jabatanData = groupByCount(data, "Jenjang Jabatan");
  const kompetensiData = groupByCount(data, "Kompetensi");

  return (
    <div style={{ padding: "20px" }}>
      <h2 style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "10px" }}>
        📊 Dashboard Geografi
      </h2>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(350px, 1fr))", gap: "30px" }}>
        {/* GENDER */}
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={genderData} dataKey="value" nameKey="name" outerRadius={80} label>
              {genderData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>

        {/* RENTANG USIA */}
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={usiaData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#8B5CF6">
              <LabelList dataKey="value" position="top" />
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        {/* JENJANG JABATAN */}
        <ResponsiveContainer width="100%" height={250}>
          <BarChart data={jabatanData}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="value" fill="#C084FC">
              <LabelList dataKey="value" position="top" />
            </Bar>
          </BarChart>
        </ResponsiveContainer>

        {/* KOMPETENSI */}
        <ResponsiveContainer width="100%" height={250}>
          <PieChart>
            <Pie data={kompetensiData} dataKey="value" nameKey="name" outerRadius={80} label>
              {kompetensiData.map((_, i) => (
                <Cell key={i} fill={COLORS[i % COLORS.length]} />
              ))}
            </Pie>
            <Tooltip />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
