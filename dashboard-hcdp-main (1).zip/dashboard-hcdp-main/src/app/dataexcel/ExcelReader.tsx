"use client";
import React, { useState } from "react";
import * as XLSX from "xlsx";

interface ExcelReaderProps {
  onDataLoaded: (data: Record<string, any[]>) => void;
}

export default function ExcelReader({ onDataLoaded }: ExcelReaderProps) {
  const [fileName, setFileName] = useState("");

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setFileName(file.name);

    const reader = new FileReader();
    reader.onload = (evt) => {
      const bstr = evt.target?.result;
      const workbook = XLSX.read(bstr, { type: "binary" });

      const targetSheets = ["worksheet", "nilai kompetensi"];

      const allSheets: Record<string, any[]> = {};
      workbook.SheetNames.forEach((name) => {
        const lower = name.toLowerCase();
        if (targetSheets.includes(lower)) {
          const sheet = workbook.Sheets[name];
          const json = XLSX.utils.sheet_to_json(sheet, { defval: "" });
          allSheets[lower] = json;
          // console.log(`Membaca sheet "${name}" => ${json.length} baris`);
        } else {
          // console.log(`Melewati sheet "${name}"`);
        }
      });

      onDataLoaded(allSheets);
    };

    reader.readAsBinaryString(file);
  };

  return (
    <div className="mb-6">
      <input type="file" accept=".xlsx, .xls" onChange={handleFileUpload} />
      {fileName && (
        <p className="text-sm text-gray-500 mt-2">
          📁 File dimuat: {fileName}
        </p>
      )}
    </div>
  );
}
