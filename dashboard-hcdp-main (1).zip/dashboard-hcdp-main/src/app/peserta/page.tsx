import React from 'react'

export default function Page () {
    return(
    <div>test halaman instansi</div>
    )
}