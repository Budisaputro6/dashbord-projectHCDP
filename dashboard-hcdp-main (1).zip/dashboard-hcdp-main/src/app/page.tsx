"use client";

import React, { useState } from "react";
import Image from "next/image";
import Sidebar from "./komponen/Sidebar";
import ExcelReader from "@/app/dataexcel/ExcelReader";

export default function Home() {
  // State untuk menampung hasil Excel
  const [data, setData] = useState<any[]>([]);

  return (
    <main style={{ display: "flex" }}>
      {/* Sidebar kamu tetap ada */}
      <Sidebar />

      {/* Konten utama */}
      <div style={{ flex: 1, padding: "20px" }}>
        <h1 style={{ fontSize: "24px", fontWeight: "bold" }}>📊 Dashboard Data Excel</h1>

        {/* Komponen untuk upload Excel */}
        <ExcelReader onDataLoaded={setData} />

        {/* 🧩 Tambahkan kode ini untuk cek isi Excel */}
        {data.length > 0 && (
          <pre
            style={{
              background: "#f8f8f8",
              padding: "10px",
              borderRadius: "8px",
              marginTop: "20px",
              fontSize: "13px",
              whiteSpace: "pre-wrap",
              maxHeight: "250px",
              overflow: "auto",
            }}
          >
            {JSON.stringify(data[0], null, 2)}
          </pre>
        )}

        {/* Tabel hasil Excel */}
        {data.length > 0 && (
          <table
            border={1}
            cellPadding={5}
            style={{
              marginTop: "20px",
              width: "100%",
              borderCollapse: "collapse",
              border: "1px solid #ccc",
            }}
          >
            <thead style={{ background: "#f5f5f5" }}>
              <tr>
                {Object.keys(data[0]).map((key) => (
                  <th key={key} style={{ textAlign: "left", padding: "8px" }}>
                    {key}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {data.map((row, i) => (
                <tr key={i}>
                  {Object.values(row).map((val, j) => (
                    <td key={j} style={{ padding: "6px", borderBottom: "1px solid #eee" }}>
                      {String(val)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </main>
  );
}
