"use client";

import React, { useState } from "react";
import ExcelReader from "@/app/dataexcel/ExcelReader";
import SectionDemografiPeserta from "./sections/SectionDemografiPeserta";
import SectionHasilPemetaan from "./sections/SectionHasilPemetaan";

export default function Page() {
  // 🔹 State untuk menampung hasil upload Excel
  const [excelData, setExcelData] = useState<Record<string, any[]>>({});

  return (
    <main style={{ display: "flex", minHeight: "100vh" }}>

      {/* Konten utama */}
      <div style={{ flex: 1, padding: "20px" }}>
        <h1 className="text-2xl font-bold mb-4 text-gray-800">📊 Dashboard Data Excel</h1>

        {/* Komponen upload file Excel */}
        <ExcelReader onDataLoaded={setExcelData} />

        {/* Jika sudah ada data Excel */}
        {Object.keys(excelData).length > 0 ? (
          <div className="space-y-12 mt-6">
            {/* Dashboard Demografi */}
            <SectionDemografiPeserta excelData={excelData} />

            {/* Dashboard Pemetaan */}
            <SectionHasilPemetaan excelData={excelData} />
          </div>
        ) : (
          <p className="text-gray-500 mt-8">Silakan upload file Excel terlebih dahulu untuk menampilkan dashboard.</p>
        )}
      </div>
    </main>
  );
}
