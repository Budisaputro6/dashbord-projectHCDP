'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  LabelList,
} from 'recharts';

/* ==================== TYPES ==================== */
type Jenis = 'Pusat' | 'Daerah';
type Pendidikan = 'D3' | 'D4 / S1' | 'S2' | 'S3';
type Gender = 'Pria' | 'Wanita';
type Jenjang =
  | 'Pemula'
  | 'Terampil'
  | 'Mahir'
  | 'Penyelia'
  | 'Pertama'
  | 'Muda'
  | 'Madya'
  | 'Utama';

type KategoriNilai = 'Optimal' | 'Cukup Optimal' | 'Kurang Optimal' | '-';

type RecordRow = {
  jenisInstansi: Jenis;
  namaInstansi: string;
  gender: Gender;
  usia: number;
  pendidikan: Pendidikan;
  jenjang: Jenjang;
  kategoriNilai: KategoriNilai;
  rekomendasi: string;
};

/* ==================== CONFIG ==================== */
const TONES = [
  '#600DB5',
  '#b599be',
  '#b6b0ba',
  '#1a0827',
  '#C885E9',
  '#7e129f',
  '#F0C6FB',
];

const KATEGORI: KategoriNilai[] = ['Optimal', 'Cukup Optimal', 'Kurang Optimal'];
const JENJANG: Jenjang[] = [
  'Pemula',
  'Terampil',
  'Mahir',
  'Penyelia',
  'Pertama',
  'Muda',
  'Madya',
  'Utama',
];
const PENDIDIKAN: Pendidikan[] = ['D3', 'D4 / S1', 'S2', 'S3'];
const USIA_BUCKETS = ['<=30', '31-40', '41-50', '>50'] as const;

const COLOR_KATEGORI: Record<KategoriNilai, string> = {
  Optimal: TONES[0],
  'Cukup Optimal': TONES[1],
  'Kurang Optimal': TONES[2],
  '-': '#ddd',
};

/* ==================== UTILS ==================== */
const usiaBucket = (u: number): (typeof USIA_BUCKETS)[number] => {
  if (u <= 30) return '<=30';
  if (u <= 40) return '31-40';
  if (u <= 50) return '41-50';
  return '>50';
};

const extractJenjang = (jenjangJabatan: string): Jenjang => {
  const words = jenjangJabatan.trim().split(/\s+/);
  const last = words[words.length - 1];
  return (last as Jenjang) || 'Pemula';
};

const applyFilters = (data: RecordRow[], jenis: string, nama: string) =>
  data.filter(
    (r) =>
      (jenis === 'All' || r.jenisInstansi === jenis) &&
      (nama === 'All' || r.namaInstansi === nama)
  );

const getSheet = (excelData: Record<string, any[]>, keyword: string) => {
  const key = Object.keys(excelData).find((k) =>
    k.toLowerCase().includes(keyword.toLowerCase())
  );
  return key ? excelData[key] : [];
};

/* ==================== COMPONENTS ==================== */
const ChartCard = ({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) => (
  <div className="rounded-2xl shadow-lg overflow-hidden border border-gray-100 bg-white">
    <div className="bg-gradient-to-r from-[#600DB5] to-[#3B82F6] text-white p-4">
      <h2 className="text-lg font-bold">{title}</h2>
      {subtitle && <p className="text-sm opacity-80">{subtitle}</p>}
    </div>
    <div className="p-4">{children}</div>
  </div>
);

/* ==================== MAIN COMPONENT ==================== */
export default function SectionHasilPemetaan({
  excelData,
}: {
  excelData: Record<string, any[]>;
}) {
  // "worksheet", "nilai kompetensi"
  const sheetUtama = getSheet(excelData, 'worksheet');
  const sheetNilai = getSheet(excelData, 'nilai kompetensi');

  const kategoriMap = new Map<string, string>();
  sheetNilai.forEach((row) => {
    if (row['NIP'])
      kategoriMap.set(String(row['NIP']).trim(), String(row['Kategori'] || '-'));
  });

  const records = useMemo((): RecordRow[] => {
    if (!Array.isArray(sheetUtama) || sheetUtama.length === 0) return [];

    const unique = Array.from(new Map(sheetUtama.map((r) => [r.NIP, r])).values());

    return unique.map((r: any) => {
      const instansi = String(r.Instansi || '').trim();
      const isPusat = instansi === 'Badan Kepegawaian Negara';
      const jenjangRaw = String(r['Jenjang Jabatan'] || '');
      const nip = String(r.NIP || '').trim();

      return {
        jenisInstansi: isPusat ? 'Pusat' : 'Daerah',
        namaInstansi: instansi || '-',
        gender: String(r.GENDER || '').toLowerCase() === 'wanita' ? 'Wanita' : 'Pria',
        usia: parseInt(String(r.USIA || 0)) || 0,
        pendidikan: (r.Pendidikan ? (r.Pendidikan as Pendidikan) : '') as Pendidikan,
        jenjang: extractJenjang(jenjangRaw),
        kategoriNilai: (kategoriMap.get(nip) as KategoriNilai) || '-',
        rekomendasi: String(r.REKOMENDASI || '-'),
      };
    });
  }, [sheetUtama, sheetNilai]);

  /* ---------- filters ---------- */
  const [jenisInstansi, setJenisInstansi] = useState('All');
  const [namaInstansi, setNamaInstansi] = useState('All');

  const namaOptions = useMemo(() => {
    const scoped =
      jenisInstansi === 'All'
        ? records
        : records.filter((r) => r.jenisInstansi === jenisInstansi);
    return ['All', ...Array.from(new Set(scoped.map((r) => r.namaInstansi))).sort()];
  }, [jenisInstansi, records]);

  useEffect(() => {
    if (!namaOptions.includes(namaInstansi)) setNamaInstansi('All');
  }, [namaOptions, namaInstansi]);

  const resetFilters = () => {
    setJenisInstansi('All');
    setNamaInstansi('All');
  };

  const filtered = useMemo(
    () => applyFilters(records, jenisInstansi, namaInstansi),
    [records, jenisInstansi, namaInstansi]
  );

  /* ---------- data aggregation ---------- */
  const dataByJenjang = useMemo(() => {
    type RowType = { name: Jenjang } & Record<KategoriNilai, number>;

    const base: RowType[] = JENJANG.map((j) => ({
      name: j,
      ...Object.fromEntries(KATEGORI.map((k) => [k, 0])),
    })) as RowType[];

    const map = new Map(base.map((b) => [b.name, b]));

    filtered.forEach((r) => {
      const row = map.get(r.jenjang);
      if (row) row[r.kategoriNilai]++;
    });

    return base;
  }, [filtered]);

  const dataByUsia = useMemo(() => {
    type RowType = { name: (typeof USIA_BUCKETS)[number] } & Record<KategoriNilai, number>;

    const base: RowType[] = USIA_BUCKETS.map((u) => ({
      name: u,
      ...Object.fromEntries(KATEGORI.map((k) => [k, 0])),
    })) as RowType[];

    const map = new Map(base.map((b) => [b.name, b]));

    filtered.forEach((r) => {
      const bucket = usiaBucket(r.usia);
      const row = map.get(bucket);
      if (row) row[r.kategoriNilai]++;
    });

    return base;
  }, [filtered]);


  const dataByGender = useMemo(() => {
    const base = KATEGORI.map((k) => ({ name: k, Pria: 0, Wanita: 0 }));
    const map = new Map(base.map((b) => [b.name, b]));
    filtered.forEach((r) => {
      const row = map.get(r.kategoriNilai);
      if (!row) return;
      if (r.gender === 'Pria') row.Pria++;
      else if (r.gender === 'Wanita') row.Wanita++;
    });
    return base;
  }, [filtered]);

  const dataByPendidikan = useMemo(() => {
    type RowType = { name: Pendidikan } & Record<KategoriNilai, number>;

    const base: RowType[] = PENDIDIKAN.map((p) => ({
      name: p,
      ...Object.fromEntries(KATEGORI.map((k) => [k, 0])),
    })) as RowType[];

    const map = new Map(base.map((b) => [b.name, b]));

    filtered.forEach((r) => {
      const row = map.get(r.pendidikan);
      if (row) row[r.kategoriNilai]++;
    });

    return base;
  }, [filtered]);


  /* ---------- render ---------- */
  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-6">
      <header>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Hasil Pemetaan</h1>
        <p className="text-sm text-gray-500">
          Menampilkan {filtered.length} dari total {records.length} peserta unik
        </p>
      </header>

      <div className="bg-white p-4 rounded-xl shadow border border-gray-200">
        <p className="text-sm text-gray-500 mb-4">
          Filterisasi untuk menyesuaikan grafik
        </p>
        <div className="flex flex-wrap gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Jenis Instansi
            </label>
            <select
              value={jenisInstansi}
              onChange={(e) => {
                setJenisInstansi(e.target.value);
                setNamaInstansi('All');
              }}
              className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500"
            >
              {['All', 'Pusat', 'Daerah'].map((o) => (
                <option key={o} value={o}>
                  {o === 'All' ? 'Semua Jenis' : o}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Nama Instansi
            </label>
            <select
              value={namaInstansi}
              onChange={(e) => setNamaInstansi(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500"
            >
              {namaOptions.map((o) => (
                <option key={o} value={o}>
                  {o}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-end">
            <button
              onClick={resetFilters}
              disabled={jenisInstansi === 'All' && namaInstansi === 'All'}
              className={`px-4 py-2 bg-gray-200 rounded-lg shadow-sm transition ${jenisInstansi === 'All' && namaInstansi === 'All'
                ? 'opacity-50 cursor-not-allowed'
                : 'hover:bg-gray-300'
                }`}
            >
              Reset
            </button>
          </div>
        </div>
      </div>

      {/* CHARTS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ChartCard title="Nilai Kompetensi per Jenjang Jabatan">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dataByJenjang}>
              <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              {KATEGORI.map((k) => (
                <Bar key={k} dataKey={k} stackId="a" fill={COLOR_KATEGORI[k]}>
                  <LabelList dataKey={k} position="top" />
                </Bar>
              ))}
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Nilai Kompetensi per Rentang Usia">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dataByUsia}>
              <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              {KATEGORI.map((k) => (
                <Bar key={k} dataKey={k} stackId="a" fill={COLOR_KATEGORI[k]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Nilai Kompetensi Berdasarkan Gender">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dataByGender}>
              <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="Pria" fill="#6C63FF" />
              <Bar dataKey="Wanita" fill="#FF9F9F" />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>

        <ChartCard title="Nilai Kompetensi Berdasarkan Pendidikan">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={dataByPendidikan}>
              <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              {KATEGORI.map((k) => (
                <Bar key={k} dataKey={k} fill={COLOR_KATEGORI[k]} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      </div>
    </div>
  );
}
