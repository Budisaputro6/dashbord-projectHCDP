'use client';

import React, { useEffect, useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  CartesianGrid,
} from 'recharts';

/* ==================== TYPES ==================== */
type Jenis = 'Pusat' | 'Daerah';
type Pendidikan = 'D3' | 'D4 / S1' | 'S2' | 'S3';
type Gender = 'Pria' | 'Wanita';
type Jabatan = 'Analis SDMA' | 'Pranata SDMA' | 'Asesor SDMA' | 'Auditor ASN';
type Jenjang =
  | 'Pemula'
  | 'Terampil'
  | 'Mahir'
  | 'Penyelia'
  | 'Pertama'
  | 'Muda'
  | 'Madya'
  | 'Utama';

type RecordRow = {
  jenisInstansi: Jenis;
  namaInstansi: string;
  gender: Gender;
  usia: number;
  pendidikan: Pendidikan;
  jabatan: Jabatan;
  jenjang: Jenjang;
};

type ExcelRow = {
  [key: string]: string | number;
};

/* ==================== CONFIG ==================== */
const TONES = [
  '#600DB5',
  '#b599be',
  '#b6b0ba',
  '#1a0827',
  '#C885E9',
  '#7e129f',
  '#F0C6FB',
];

/* ==================== UTILS ==================== */
const usiaBucket = (u: number): '<30' | '31-40' | '41-50' | '>50' => {
  if (u < 30) return '<30';
  if (u <= 40) return '31-40';
  if (u <= 50) return '41-50';
  return '>50';
};

const extractJenjang = (jenjangJabatan: string): Jenjang => {
  const words = jenjangJabatan.trim().split(/\s+/);
  const lastWord = words[words.length - 1] || '';
  return lastWord as Jenjang;
};

const extractJabatan = (jenjangJabatan: string): Jabatan => {
  if (jenjangJabatan.includes('Analis')) return 'Analis SDMA';
  if (jenjangJabatan.includes('Pranata')) return 'Pranata SDMA';
  if (jenjangJabatan.includes('Asesor')) return 'Asesor SDMA';
  if (jenjangJabatan.includes('Auditor')) return 'Auditor ASN';
  return 'Pranata SDMA';
};

const applyFilters = (data: RecordRow[], jenis: string, nama: string) =>
  data.filter(
    (r) =>
      (jenis === 'All' || r.jenisInstansi === jenis) &&
      (nama === 'All' || r.namaInstansi === nama)
  );

const getSheet = (excelData: Record<string, any[]>, keyword: string) => {
  const key = Object.keys(excelData).find((k) =>
    k.toLowerCase().includes(keyword.toLowerCase())
  );
  return key ? excelData[key] : [];
};

/* ==================== UI COMPONENTS ==================== */
const ChartCard = ({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) => (
  <div className="rounded-2xl shadow-lg overflow-hidden border border-gray-100 bg-white">
    <div className="bg-gradient-to-r from-[#600DB5] to-[#3B82F6] text-white p-4">
      <h2 className="text-lg font-bold">{title}</h2>
      {subtitle && <p className="text-sm opacity-80">{subtitle}</p>}
    </div>
    <div className="p-4">{children}</div>
  </div>
);

/* ==================== MAIN COMPONENT ==================== */
export default function SectionDemografiPeserta({
  excelData,
}: {
  excelData: any;
}) {
  const sheetData = useMemo(() => {
    if (!excelData) return [];
    if (Array.isArray(excelData)) return excelData;
    return getSheet(excelData, 'worksheet');
  }, [excelData]);

  /* ---------- Konversi data ---------- */
  const records = useMemo((): RecordRow[] => {
    if (!Array.isArray(sheetData) || sheetData.length === 0) return [];

    const unique = Array.from(new Map(sheetData.map((r) => [r.NIP, r])).values());

    return unique.map((r: ExcelRow) => {
      const instansi = String(r.Instansi || '').trim();
      const isPusat = instansi === 'Badan Kepegawaian Negara';
      const jenjangJabatanRaw = String(r['Jenjang Jabatan'] || '');

      return {
        jenisInstansi: isPusat ? 'Pusat' : 'Daerah',
        namaInstansi: instansi || '-',
        gender: String(r.GENDER || '').toLowerCase() === 'wanita' ? 'Wanita' : 'Pria',
        usia: parseInt(String(r.USIA || 0)) || 0,
        pendidikan: (r.Pendidikan ? (r.Pendidikan as Pendidikan) : '') as Pendidikan,
        jabatan: extractJabatan(jenjangJabatanRaw),
        jenjang: extractJenjang(jenjangJabatanRaw),
      };
    });
  }, [sheetData]);

  /* ---------- Filter state ---------- */
  const [jenisInstansi, setJenisInstansi] = useState<string>('All');
  const [namaInstansi, setNamaInstansi] = useState<string>('All');

  const namaOptions = useMemo(() => {
    const scoped =
      jenisInstansi === 'All'
        ? records
        : records.filter((r) => r.jenisInstansi === jenisInstansi);
    return ['All', ...Array.from(new Set(scoped.map((r) => r.namaInstansi))).sort()];
  }, [jenisInstansi, records]);

  useEffect(() => {
    if (!namaOptions.includes(namaInstansi)) setNamaInstansi('All');
  }, [namaOptions, namaInstansi]);

  const resetFilters = () => {
    setJenisInstansi('All');
    setNamaInstansi('All');
  };

  const filtered = useMemo(
    () => applyFilters(records, jenisInstansi, namaInstansi),
    [records, jenisInstansi, namaInstansi]
  );

  const { byGender, byJenis, byPendidikan, byUsia, byJabatan, jenjangKeys } = useMemo(
    () => {
      const byGender = [
        { name: 'Pria', value: filtered.filter((r) => r.gender === 'Pria').length },
        { name: 'Wanita', value: filtered.filter((r) => r.gender === 'Wanita').length },
      ];
      const byJenis = [
        { name: 'Pusat', value: filtered.filter((r) => r.jenisInstansi === 'Pusat').length },
        { name: 'Daerah', value: filtered.filter((r) => r.jenisInstansi === 'Daerah').length },
      ];
      const byPendidikan = (['D3', 'D4 / S1', 'S2', 'S3'] as Pendidikan[]).map((p) => ({
        name: p,
        value: filtered.filter((r) => r.pendidikan === p).length,
      }));
      const byUsia = (['<30', '31-40', '41-50', '>50'] as const).map((range) => ({
        range,
        total: filtered.filter((r) => usiaBucket(r.usia) === range).length,
      }));
      const jabatanLabels: Jabatan[] = [
        'Analis SDMA',
        'Pranata SDMA',
        'Asesor SDMA',
        'Auditor ASN',
      ];
      const jenjangKeys: Jenjang[] = [
        'Pemula',
        'Terampil',
        'Mahir',
        'Penyelia',
        'Pertama',
        'Muda',
        'Madya',
        'Utama',
      ];
      const byJabatan = jabatanLabels.map((j) => {
        const slice = filtered.filter((r) => r.jabatan === j);
        const row: any = { jabatan: j };
        for (const k of jenjangKeys)
          row[k] = slice.filter((r) => r.jenjang === k).length;
        return row;
      });
      return { byGender, byJenis, byPendidikan, byUsia, byJabatan, jenjangKeys };
    },
    [filtered]
  );

  /* ---------- Render ---------- */
  const isDefault = jenisInstansi === 'All' && namaInstansi === 'All';

  return (
    <div className="min-h-screen bg-gray-50 p-6 space-y-6">
      <header className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Dashboard Demografi Peserta
          </h1>
          <p className="text-sm text-gray-500">
            {records.length > 0
              ? `Menampilkan data dari ${filtered.length} peserta (dari total ${records.length} peserta unik)`
              : 'Data akan tampil setelah file Excel dimuat.'}
          </p>
        </div>
      </header>

      {records.length > 0 && (
        <>
          {/* Filter */}
          <div className="bg-white p-4 rounded-xl shadow border border-gray-200">
            <p className="text-sm text-gray-500 mb-4">
              Filterisasi untuk menyesuaikan grafik
            </p>
            <div className="flex flex-wrap gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Jenis Instansi
                </label>
                <select
                  value={jenisInstansi}
                  onChange={(e) => {
                    setJenisInstansi(e.target.value);
                    setNamaInstansi('All');
                  }}
                  className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500"
                >
                  {['All', 'Pusat', 'Daerah'].map((o) => (
                    <option key={o} value={o}>
                      {o === 'All' ? 'Semua Jenis' : o}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nama Instansi
                </label>
                <select
                  value={namaInstansi}
                  onChange={(e) => setNamaInstansi(e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-indigo-500"
                >
                  {namaOptions.map((o) => (
                    <option key={o} value={o}>
                      {o}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={resetFilters}
                  disabled={isDefault}
                  className={`px-4 py-2 bg-gray-200 rounded-lg shadow-sm transition ${isDefault
                      ? 'opacity-50 cursor-not-allowed'
                      : 'hover:bg-gray-300'
                    }`}
                >
                  Reset
                </button>
              </div>
            </div>
          </div>

          {/* Charts */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <ChartCard title="Gender" subtitle="Distribusi Berdasarkan Jenis Kelamin">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={byGender} dataKey="value" nameKey="name" outerRadius={80} label>
                    {byGender.map((_, i) => (
                      <Cell key={i} fill={TONES[i]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Jenis Instansi" subtitle="Pusat vs Daerah">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={byJenis} dataKey="value" nameKey="name" innerRadius={40} outerRadius={80} label>
                    {byJenis.map((_, i) => (
                      <Cell key={i} fill={TONES[i + 2]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard title="Pendidikan" subtitle="Tingkat Pendidikan Terakhir">
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie data={byPendidikan} dataKey="value" nameKey="name" outerRadius={80} label>
                    {byPendidikan.map((_, i) => (
                      <Cell key={i} fill={TONES[i + 4]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <ChartCard title="Usia" subtitle="Distribusi Berdasarkan Rentang Usia">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={byUsia}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
                  <XAxis dataKey="range" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="total" name="Jumlah" radius={[6, 6, 0, 0]}>
                    {byUsia.map((_, i) => (
                      <Cell key={i} fill={TONES[i % TONES.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>

            <ChartCard
              title="Pegawai per Jenjang Jabatan"
              subtitle="Distribusi Berdasarkan Jabatan dan Jenjang"
            >
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={byJabatan}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#e5e7eb" />
                  <XAxis dataKey="jabatan" angle={-15} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  {jenjangKeys.map((k, i) => (
                    <Bar key={k} dataKey={k} fill={TONES[i % TONES.length]} stackId="a" />
                  ))}
                </BarChart>
              </ResponsiveContainer>
            </ChartCard>
          </div>
        </>
      )}
    </div>
  );
}
