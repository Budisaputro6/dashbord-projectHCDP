// src/app/admin/sections/data/instansiKategori.ts

export const instansiKategoriData = [
  { instansi: "Kementerian Koordinator Bidang Infrastruktur dan Tata Ruang", kategori: "Kementerian Koordinator" },
  { instansi: "Kementerian Lingkungan Hidup/Badan Pengendalian Perubahan Iklim", kategori: "Kementerian" },
  { instansi: "Kementerian Perumahan dan Kawasan Permukiman", kategori: "Kementerian" },
  { instansi: "Kementerian Energi dan Sumber Daya Mineral", kategori: "Kementerian" },
  { instansi: "Kementerian Perhubungan", kategori: "Kementerian" },
  // ... semua 643 instansi lengkap
];
