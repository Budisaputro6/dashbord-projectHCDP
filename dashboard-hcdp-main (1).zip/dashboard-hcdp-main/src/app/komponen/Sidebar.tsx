"use client";

import React, { useState } from "react";
import { UserCog, Building2, Users, HamburgerIcon } from "lucide-react"; // ikon lucide-react
import Link from "next/link";

const Sidebar = () => {
  const [active, setActive] = useState("Admin");

  const menus = [
    { name: "Admin", icon: UserCog, link: "/admin" },
    { name: "Dashboard", icon: HamburgerIcon, link: "/dashboard" },
    { name: "Instansi", icon: Building2, link: "/instansi" },
    { name: "Peserta", icon: Users, link: "/peserta" },
  ];

  return (
    <aside
      className="w-64 min-h-screen bg-white border-r border-gray-200 shadow-md 
      flex flex-col font-[Inter]"
    >
      {/* Title / Brand */}
      <div className="p-6 border-b border-gray-100">
        <h1 className="text-xl font-bold tracking-tight text-[#600DB5] uppercase">
          Dashboard HCDP
        </h1>
      </div>

      {/* Navigation */}
      <nav className="flex flex-col p-4 gap-1 flex-1">
        {menus.map((menu) => {
          const Icon = menu.icon;
          const isActive = active === menu.name;
          return (
            <Link key={menu.name} href={menu.link}>
              <button
                onClick={() => setActive(menu.name)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium 
                  transition-all duration-200 w-full text-left
                  ${isActive
                    ? "bg-[#600DB5] text-white shadow-sm"
                    : "text-gray-700 hover:bg-[#F3E8FF] hover:text-[#600DB5]"
                  }`}
              >
                <Icon
                  size={20}
                  className={`${isActive ? "text-white" : "text-gray-400 group-hover:text-[#600DB5]"
                    }`}
                />
                <span>{menu.name}</span>
              </button>
            </Link>
          );
        })}
      </nav>

      {/* Footer / Info */}
      <div className="p-4 border-t border-gray-100 text-xs text-gray-400">
        © {new Date().getFullYear()} HCDP. All rights reserved.
      </div>
    </aside>
  );
};

export default Sidebar;
